﻿using System.Windows.Controls;

namespace Dragablz
{
    public class VerticalOrganiser : StackOrganiser
    {
        public VerticalOrganiser() : base(Orientation.Vertical)
        {
        }
    }
}
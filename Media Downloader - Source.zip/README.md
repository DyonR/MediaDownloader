# Media Downloader
Media Downloader is a graphical user interface for [youtube-dl](https://github.com/rg3/youtube-dl) and [RipMe](https://github.com/4pr0n/ripme).
